/**
 * ============================================================
 * VELVET AGENCY — Premium PWA Application
 * Project: abdelatizarzori3-sys
 * Owner: Abdelati Zarzori
 * ============================================================
 */

// ============================================
// SUPABASE CONFIGURATION
// ============================================
// IMPORTANT: Replace with your actual keys from Supabase Dashboard
// Settings → API → Project URL & anon public key
const SUPABASE_URL = 'https://abdelatizarzori3-sys.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...'; // ← استبدل هذا بمفتاحك الحقيقي

// ============================================
// ADMIN WHATSAPP NUMBER (لاستقبال طلبات العملاء)
// استبدل هذا برقمك الشخصي مع رمز الدولة (بدون +)
// مثال: '212600000000' للمغرب
// ============================================
const ADMIN_WHATSAPP = '212600000000'; // ← استبدل هذا برقمك

// Initialize Supabase Client using global supabase from CDN
let supabase = null;

function initSupabase() {
  try {
    if (typeof window.supabase !== 'undefined' && window.supabase.createClient) {
      const { createClient } = window.supabase;
      supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
        auth: {
          autoRefreshToken: true,
          persistSession: true,
          detectSessionInUrl: true
        },
        db: {
          schema: 'public'
        }
      });
      console.log('%c Velvet Agency ', 'background: #d4af37; color: #0f172a; font-weight: bold; padding: 4px 8px; border-radius: 4px;', 'Supabase connected successfully');
      return true;
    } else {
      console.warn('Velvet Agency: Supabase library not loaded yet, retrying...');
      return false;
    }
  } catch (error) {
    console.error('Velvet Agency: Failed to initialize Supabase:', error);
    return false;
  }
}

// Retry initialization
if (!initSupabase()) {
  const retryInterval = setInterval(() => {
    if (initSupabase()) {
      clearInterval(retryInterval);
    }
  }, 1000);
  setTimeout(() => clearInterval(retryInterval), 10000);
}

// ============================================
// SERVICE WORKER REGISTRATION (PWA)
// ============================================
if ('serviceWorker' in navigator) {
  window.addEventListener('load', async () => {
    try {
      const registration = await navigator.serviceWorker.register('sw.js');
      console.log('Velvet Agency SW: Registered:', registration.scope);
    } catch (error) {
      console.error('Velvet Agency SW: Registration failed:', error);
    }
  });
}

// ============================================
// PWA INSTALL PROMPT
// ============================================
let deferredPrompt = null;
const installBtn = document.getElementById('install-btn');
const installBtnMobile = document.getElementById('install-btn-mobile');

window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  deferredPrompt = e;
  if (installBtn) installBtn.style.display = 'inline-flex';
  if (installBtnMobile) installBtnMobile.style.display = 'inline-flex';
  console.log('Velvet Agency: PWA install ready');
});

function handleInstallClick() {
  if (!deferredPrompt) {
    alert('التطبيق مثبت بالفعل أو غير مدعوم على هذا المتصفح. يمكنك إضافة الموقع للشاشة الرئيسية يدوياً.');
    return;
  }
  deferredPrompt.prompt();
  deferredPrompt.userChoice.then((choiceResult) => {
    if (choiceResult.outcome === 'accepted') {
      console.log('Velvet Agency: PWA installed');
      if (installBtn) installBtn.style.display = 'none';
      if (installBtnMobile) installBtnMobile.style.display = 'none';
    }
    deferredPrompt = null;
  });
}

if (installBtn) installBtn.addEventListener('click', handleInstallClick);
if (installBtnMobile) installBtnMobile.addEventListener('click', handleInstallClick);

window.addEventListener('appinstalled', () => {
  console.log('Velvet Agency: PWA installed');
  if (installBtn) installBtn.style.display = 'none';
  if (installBtnMobile) installBtnMobile.style.display = 'none';
  deferredPrompt = null;
});

// ============================================
// NAVBAR SCROLL EFFECT
// ============================================
const navbar = document.getElementById('navbar');
window.addEventListener('scroll', () => {
  if (window.scrollY > 50) {
    navbar.classList.add('scrolled');
  } else {
    navbar.classList.remove('scrolled');
  }
});

// ============================================
// MOBILE MENU
// ============================================
const hamburger = document.getElementById('hamburger');
const mobileMenu = document.getElementById('mobile-menu');
const mobileMenuOverlay = document.getElementById('mobile-menu-overlay');
const mobileLinks = document.querySelectorAll('.mobile-link');

function toggleMobileMenu() {
  hamburger.classList.toggle('active');
  mobileMenu.classList.toggle('active');
  mobileMenuOverlay.classList.toggle('active');
  document.body.style.overflow = mobileMenu.classList.contains('active') ? 'hidden' : '';
}

if (hamburger) hamburger.addEventListener('click', toggleMobileMenu);
if (mobileMenuOverlay) mobileMenuOverlay.addEventListener('click', toggleMobileMenu);
mobileLinks.forEach(link => link.addEventListener('click', toggleMobileMenu));

// ============================================
// PARTICLES ANIMATION (Hero Background)
// ============================================
const canvas = document.getElementById('particles-canvas');
if (canvas) {
  const ctx = canvas.getContext('2d');
  let particles = [];
  let animationId = null;

  function resizeCanvas() {
    canvas.width = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;
  }

  function createParticles() {
    particles = [];
    const count = Math.min(50, Math.floor(canvas.width / 20));
    for (let i = 0; i < count; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        radius: Math.random() * 2 + 0.5,
        speedX: (Math.random() - 0.5) * 0.5,
        speedY: (Math.random() - 0.5) * 0.5,
        opacity: Math.random() * 0.5 + 0.1
      });
    }
  }

  function drawParticles() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    particles.forEach(p => {
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(212, 175, 55, ${p.opacity})`;
      ctx.fill();
      p.x += p.speedX; p.y += p.speedY;
      if (p.x < 0) p.x = canvas.width;
      if (p.x > canvas.width) p.x = 0;
      if (p.y < 0) p.y = canvas.height;
      if (p.y > canvas.height) p.y = 0;
    });
    for (let i = 0; i < particles.length; i++) {
      for (let j = i + 1; j < particles.length; j++) {
        const dx = particles[i].x - particles[j].x;
        const dy = particles[i].y - particles[j].y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < 100) {
          ctx.beginPath();
          ctx.moveTo(particles[i].x, particles[i].y);
          ctx.lineTo(particles[j].x, particles[j].y);
          ctx.strokeStyle = `rgba(212, 175, 55, ${0.1 * (1 - dist / 100)})`;
          ctx.lineWidth = 0.5;
          ctx.stroke();
        }
      }
    }
    animationId = requestAnimationFrame(drawParticles);
  }

  resizeCanvas();
  createParticles();
  drawParticles();
  window.addEventListener('resize', () => { resizeCanvas(); createParticles(); });
}

// ============================================
// AOS INITIALIZATION
// ============================================
document.addEventListener('DOMContentLoaded', () => {
  if (typeof AOS !== 'undefined') {
    AOS.init({
      duration: 800,
      easing: 'ease-out-cubic',
      once: true,
      offset: 100,
      disable: function() { return window.innerWidth < 768; }
    });
  }
});

// ============================================
// WHATSAPP MESSAGE GENERATOR
// ============================================
function generateWhatsAppMessage(formData) {
  const packageLabels = {
    monthly: 'الباقة الشهرية الماسية',
    quarterly: 'الباقة الربع سنوية الملكية',
    yearly: 'الباقة السنوية الإمبراطورية'
  };

  return `
🎩 *طلب جديد من Velvet Agency*

🏢 *اسم الشركة:* ${formData.company_name}
📱 *رقم الواتساب:* ${formData.whatsapp}
🏭 *نوع النشاط:* ${formData.business_type}
📦 *الباقة المختارة:* ${packageLabels[formData.package] || formData.package}
📝 *ملاحظات:* ${formData.notes || 'لا توجد ملاحظات'}

⏰ *وقت الإرسال:* ${new Date().toLocaleString('ar-SA')}

✨ يرجى التواصل مع العميل في أقرب وقت.
  `.trim();
}

function openWhatsApp(phone, message) {
  const cleanPhone = phone.replace(/\D/g, '');
  const encodedMessage = encodeURIComponent(message);
  const waUrl = `https://wa.me/${cleanPhone}?text=${encodedMessage}`;
  window.open(waUrl, '_blank');
}

// ============================================
// LEAD FORM HANDLING (Supabase + WhatsApp)
// ============================================
const leadForm = document.getElementById('lead-form');
const submitBtn = document.getElementById('submit-btn');
const btnText = document.getElementById('btn-text');
const btnIcon = document.getElementById('btn-icon');
const btnSpinner = document.getElementById('btn-spinner');
const successModal = document.getElementById('success-modal');
const modalClose = document.getElementById('modal-close');
const modalOk = document.getElementById('modal-ok');

function showLoading() {
  btnText.textContent = 'جاري إرسال طلبك الفاخر...';
  btnIcon.classList.add('hidden');
  btnSpinner.classList.remove('hidden');
  submitBtn.disabled = true;
  submitBtn.style.opacity = '0.8';
}

function hideLoading() {
  btnText.textContent = 'إرسال الطلب الفاخر';
  btnIcon.classList.remove('hidden');
  btnSpinner.classList.add('hidden');
  submitBtn.disabled = false;
  submitBtn.style.opacity = '1';
}

function showSuccessModal() {
  successModal.classList.add('active');
  document.body.style.overflow = 'hidden';
}

function hideSuccessModal() {
  successModal.classList.remove('active');
  document.body.style.overflow = '';
}

if (modalClose) modalClose.addEventListener('click', hideSuccessModal);
if (modalOk) modalOk.addEventListener('click', hideSuccessModal);
successModal.addEventListener('click', (e) => { if (e.target === successModal) hideSuccessModal(); });

if (leadForm) {
  leadForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const formData = {
      company_name: document.getElementById('company-name').value.trim(),
      whatsapp: document.getElementById('whatsapp').value.trim(),
      business_type: document.getElementById('business-type').value.trim(),
      package: document.getElementById('package').value,
      notes: document.getElementById('notes').value.trim() || '',
      status: 'new',
      created_at: new Date().toISOString()
    };

    if (!formData.company_name || !formData.whatsapp || !formData.business_type || !formData.package) {
      alert('الرجاء ملء جميع الحقول المطلوبة');
      return;
    }

    showLoading();
    let savedToSupabase = false;

    // 1. حفظ في Supabase
    try {
      if (supabase) {
        const { data, error } = await supabase
          .from('leads')
          .insert([formData])
          .select();

        if (error) throw error;
        console.log('Velvet Agency: Lead saved to Supabase:', data);
        savedToSupabase = true;
      }
    } catch (error) {
      console.error('Velvet Agency: Supabase error:', error);
      // Fallback: Store locally
      try {
        const localLeads = JSON.parse(localStorage.getItem('velvet_leads') || '[]');
        localLeads.push(formData);
        localStorage.setItem('velvet_leads', JSON.stringify(localLeads));
      } catch (localError) {
        console.error('Local storage failed:', localError);
      }
    }

    // 2. فتح واتساب برسالة تلقائية (دائماً يعمل حتى لو فشل Supabase)
    try {
      const message = generateWhatsAppMessage(formData);
      openWhatsApp(ADMIN_WHATSAPP, message);
    } catch (waError) {
      console.error('WhatsApp error:', waError);
    }

    hideLoading();
    leadForm.reset();
    showSuccessModal();
  });
}

// ============================================
// TERMS MODAL
// ============================================
const termsModal = document.getElementById('terms-modal');
const termsLink = document.getElementById('terms-link');
const privacyLink = document.getElementById('privacy-link');
const termsFooterLink = document.getElementById('terms-footer-link');
const ipLink = document.getElementById('ip-link');
const termsModalClose = document.getElementById('terms-modal-close');
const termsModalOk = document.getElementById('terms-modal-ok');

function showTermsModal(e) {
  if (e) e.preventDefault();
  termsModal.classList.add('active');
  document.body.style.overflow = 'hidden';
}

function hideTermsModal() {
  termsModal.classList.remove('active');
  document.body.style.overflow = '';
}

if (termsLink) termsLink.addEventListener('click', showTermsModal);
if (privacyLink) privacyLink.addEventListener('click', showTermsModal);
if (termsFooterLink) termsFooterLink.addEventListener('click', showTermsModal);
if (ipLink) ipLink.addEventListener('click', showTermsModal);
if (termsModalClose) termsModalClose.addEventListener('click', hideTermsModal);
if (termsModalOk) termsModalOk.addEventListener('click', hideTermsModal);
termsModal.addEventListener('click', (e) => { if (e.target === termsModal) hideTermsModal(); });

// ============================================
// SMOOTH SCROLL
// ============================================
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function(e) {
    const href = this.getAttribute('href');
    if (href === '#') return;
    const target = document.querySelector(href);
    if (target) {
      e.preventDefault();
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  });
});

// ============================================
// WHATSAPP FLOAT BUTTON
// ============================================
const whatsappFloat = document.querySelector('.whatsapp-float');
if (whatsappFloat) {
  whatsappFloat.style.opacity = '0';
  whatsappFloat.style.transform = 'scale(0)';
  whatsappFloat.style.transition = 'all 0.5s cubic-bezier(0.4, 0, 0.2, 1)';
  setTimeout(() => {
    whatsappFloat.style.opacity = '1';
    whatsappFloat.style.transform = 'scale(1)';
  }, 2000);
}

// ============================================
// CONSOLE BRANDING
// ============================================
console.log('%c Velvet Agency ', 'background: linear-gradient(135deg, #d4af37, #b8941f); color: #0f172a; font-size: 24px; font-weight: bold; padding: 10px 20px; border-radius: 10px;');
console.log('%c Founded by Abdelati Zarzori ', 'color: #d4af37; font-size: 14px;');
console.log('%c Premium Cinematic AI Agency — abdelatizarzori3-sys.supabase.co ', 'color: #c0c0c0; font-size: 12px;');

// ============================================
// OFFLINE DETECTION
// ============================================
window.addEventListener('online', () => console.log('Velvet Agency: Online'));
window.addEventListener('offline', () => console.log('Velvet Agency: Offline mode'));
